﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;




namespace ClassLibrary1
{
    public class Class1
    {
        IWebDriver drive = new ChromeDriver();

       // d.Url="https//:google.com";
    }
}
